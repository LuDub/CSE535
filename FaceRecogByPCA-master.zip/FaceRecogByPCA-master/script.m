clc,clear;

trainingDataPathList1 = getNodes(uigetdir('.','trainingDataPathList1'));

 imgcount = size(trainingDataPathList1 , 1);
   % f = [];
    for i=1 : imgcount
       % f = [f , imreadOneD( trainingDataPathList(i,: ))];
      % [f p] = uigetfile('*.jpg', 'C:\Users\Victor\Documents\MATLAB\FaceRecogByPCA-master\FaceRecogByPCA-master\PICS_database\Training3\Training_0i');
       % path = [p f];

        %I = imread(path);
	    I = imread(trainingDataPathList1(i,: ));
        gray = double(I(:,:,1));

        [u, s, v] = svds(gray);
        imgray = uint8( u * s * transpose(v));

        figure,

        subplot(1,1,1), subimage(imgray,title('OUTPUT IMAGE'))
        imageinfo;
        imsave
    
    end



trainingDataPathList = getNodes(uigetdir('.','trainingDataPathList'));
[filename, pathname]  = uigetfile('.','testImgPath');
testImgPath = [pathname filename];
facerecog(trainingDataPathList,testImgPath);